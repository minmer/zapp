import React, { useEffect, useState } from "react";
import { Editable, EditableProps } from "./Editable";

interface EditableDisplayProps {
    editableProps: EditableProps;
    token: string;
}

const EditableDisplay: React.FC<EditableDisplayProps> = ({ editableProps, getParams }) => {
    const [editable, setEditable] = useState<Editable | null>(null);
    const [displayText, setDisplayText] = useState<string>("Loading...");

    useEffect(() => {
        const instance = new Editable(editableProps);

        // Listener function to update the display text when data changes
        const handleDataChange = () => {
            if (instance.data.length > 0) {
                // Convert data array to a formatted string
                const formattedData = instance.data.map(item => item.output).join(", ");
                setDisplayText(formattedData);
            } else {
                setDisplayText("No data available.");
            }
        };

        instance.addListener(handleDataChange);
        setEditable(instance);

        // Check permission and load data if permitted
        (async () => {
            await instance.checkPermission(token);
            if (instance.hasPermission) {
                await instance.fetchData(token);
            } else {
                setDisplayText("Permission denied.");
            }
        })();

        // Clean up listener on component unmount
        return () => {
            instance.removeListener(handleDataChange);
        };
    }, [editableProps, token]);

    return (
        <div>
            <h3>{editable?.description}</h3>
            <p>{displayText}</p>
        </div>
    );
};

export default EditableDisplay;